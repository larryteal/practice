// 单例 browser

const puppeteer = require("puppeteer");
const config = require('./config');//
const deasync = require('deasync');
const BROWSER_KEY = Symbol.for('browser');
const BROWSER_STATUS_KEY = Symbol.for('browser_status');

launch(config.browserOptions)
wait4Lunch();

/**
 * 启动并获取浏览器实例
 * @param {*} options
 * param options is puppeteer.launch function's options
 */
function launch(options = {}) {
  if (!global[BROWSER_STATUS_KEY]) {
    global[BROWSER_STATUS_KEY] = 'lunching';
    puppeteer.launch(options)
      .then((browser) => {
        global[BROWSER_KEY] = browser;
        global[BROWSER_STATUS_KEY] = 'lunched';
      })
      .catch((err) => {
        global[BROWSER_STATUS_KEY] = 'error';
        throw err;
      });
  }
}

function wait4Lunch(){
  while (!global[BROWSER_KEY] && global[BROWSER_STATUS_KEY] == 'lunching') {
    // wait for lunch
    deasync.runLoopOnce();
  }
}

module.exports = global[BROWSER_KEY];