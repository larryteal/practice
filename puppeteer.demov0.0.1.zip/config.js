module.exports = {
  browserOptions:{
    headless: true,
    args: ['--no-sandbox']
  }
};